package Opgave2;

public class Main {
    public static void main(String[] args){
        Cirkel c1 = new Cirkel();
        System.out.println("Arealet af cirklen er: " +c1.areal(-5));
    }
}
